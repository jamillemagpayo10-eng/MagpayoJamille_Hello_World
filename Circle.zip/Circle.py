# Area of Circle

MagpayoRadius = float(input("Enter radius: "))

MagpayoArea = 3.14 * MagpayoRadius * MagpayoRadius

print("Area of the circle is:", MagpayoArea)
